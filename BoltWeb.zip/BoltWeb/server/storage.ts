import {
  users,
  messages,
  attachments,
  documents,
  uploadQueue,
  type User,
  type UpsertUser,
  type Message,
  type InsertMessage,
  type Attachment,
  type InsertAttachment,
  type Document,
  type InsertDocument,
  type UploadItem,
  type InsertUploadItem,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Message operations
  getMessages(userId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Attachment operations
  getAttachments(messageId: string): Promise<Attachment[]>;
  createAttachment(attachment: InsertAttachment): Promise<Attachment>;
  
  // Document operations
  getDocuments(userId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  getDocumentsByDateRange(userId: string, startDate?: Date, endDate?: Date): Promise<Document[]>;
  
  // Upload operations
  getUploadQueue(userId: string): Promise<UploadItem[]>;
  createUpload(upload: InsertUploadItem): Promise<UploadItem>;
  updateUploadStatus(id: string, status: string, progress?: number): Promise<void>;
  
  // Dashboard stats
  getDashboardStats(userId: string): Promise<{
    totalDocuments: number;
    totalValue: number;
    duingToday: number;
    processedEmails: number;
  }>;
  
  getMonthlyValues(userId: string): Promise<Array<{ month: string; value: number }>>;
  getStatusCounts(userId: string): Promise<Array<{ status: string; count: number }>>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private messages: Map<string, Message> = new Map();
  private attachments: Map<string, Attachment> = new Map();
  private documents: Map<string, Document> = new Map();
  private uploadQueue: Map<string, UploadItem> = new Map();

  constructor() {
    // Initialize with sample data for demo
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Adicionar alguns dados de exemplo para demonstração
    const sampleUserId = "demo-user-123";
    
    // Criar usuário de demonstração
    this.users.set(sampleUserId, {
      id: sampleUserId,
      email: "demo@exemplo.com",
      firstName: "Demo",
      lastName: "Usuário",
      profileImageUrl: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    // Criar algumas mensagens de exemplo
    const message1 = {
      id: "msg-1",
      userId: sampleUserId,
      subject: "Fatura Cartão de Crédito - Janeiro 2025",
      fromEmail: "cartao@banco.com.br",
      receivedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      hasAttachments: true,
      createdAt: new Date(),
    };

    const message2 = {
      id: "msg-2", 
      userId: sampleUserId,
      subject: "Boleto Vencimento 30/01/2025",
      fromEmail: "cobranca@empresa.com.br",
      receivedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      hasAttachments: true,
      createdAt: new Date(),
    };

    this.messages.set(message1.id, message1);
    this.messages.set(message2.id, message2);

    // Criar alguns documentos de exemplo
    const doc1 = {
      id: "doc-1",
      messageId: message1.id,
      attachmentId: null,
      userId: sampleUserId,
      name: "Fatura Cartão Janeiro",
      value: "1250.50",
      issueDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      status: "pending",
      confidence: "92.5",
      createdAt: new Date(),
    };

    const doc2 = {
      id: "doc-2",
      messageId: message2.id,
      attachmentId: null,
      userId: sampleUserId,
      name: "Boleto Energia Elétrica",
      value: "345.80",
      issueDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      status: "processed",
      confidence: "88.0",
      createdAt: new Date(),
    };

    const doc3 = {
      id: "doc-3",
      messageId: null,
      attachmentId: null,
      userId: sampleUserId,
      name: "Recibo Aluguel",
      value: "2100.00",
      issueDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
      dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      status: "expired",
      confidence: "95.0",
      createdAt: new Date(),
    };

    this.documents.set(doc1.id, doc1);
    this.documents.set(doc2.id, doc2);
    this.documents.set(doc3.id, doc3);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id!);
    const user: User = {
      ...userData,
      id: userData.id || randomUUID(),
      createdAt: existingUser?.createdAt || new Date(),
      updatedAt: new Date(),
    } as User;
    
    this.users.set(user.id, user);
    return user;
  }

  async getMessages(userId: string): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(msg => msg.userId === userId);
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const message: Message = {
      ...messageData,
      id: randomUUID(),
      createdAt: new Date(),
    } as Message;
    
    this.messages.set(message.id, message);
    return message;
  }

  async getAttachments(messageId: string): Promise<Attachment[]> {
    return Array.from(this.attachments.values()).filter(att => att.messageId === messageId);
  }

  async createAttachment(attachmentData: InsertAttachment): Promise<Attachment> {
    const attachment: Attachment = {
      ...attachmentData,
      id: randomUUID(),
      createdAt: new Date(),
    } as Attachment;
    
    this.attachments.set(attachment.id, attachment);
    return attachment;
  }

  async getDocuments(userId: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(doc => doc.userId === userId);
  }

  async createDocument(documentData: InsertDocument): Promise<Document> {
    const document: Document = {
      ...documentData,
      id: randomUUID(),
      createdAt: new Date(),
    } as Document;
    
    this.documents.set(document.id, document);
    return document;
  }

  async getDocumentsByDateRange(userId: string, startDate?: Date, endDate?: Date): Promise<Document[]> {
    const userDocs = await this.getDocuments(userId);
    
    if (!startDate && !endDate) {
      return userDocs;
    }
    
    return userDocs.filter(doc => {
      if (!doc.issueDate) return false;
      const issueDate = new Date(doc.issueDate);
      
      if (startDate && issueDate < startDate) return false;
      if (endDate && issueDate > endDate) return false;
      
      return true;
    });
  }

  async getUploadQueue(userId: string): Promise<UploadItem[]> {
    return Array.from(this.uploadQueue.values()).filter(item => item.userId === userId);
  }

  async createUpload(uploadData: InsertUploadItem): Promise<UploadItem> {
    const upload: UploadItem = {
      ...uploadData,
      id: randomUUID(),
      createdAt: new Date(),
    } as UploadItem;
    
    this.uploadQueue.set(upload.id, upload);
    return upload;
  }

  async updateUploadStatus(id: string, status: string, progress?: number): Promise<void> {
    const upload = this.uploadQueue.get(id);
    if (upload) {
      upload.status = status;
      if (progress !== undefined) {
        upload.progress = progress.toString();
      }
      this.uploadQueue.set(id, upload);
    }
  }

  async getDashboardStats(userId: string): Promise<{
    totalDocuments: number;
    totalValue: number;
    duingToday: number;
    processedEmails: number;
  }> {
    const documents = await this.getDocuments(userId);
    const messages = await this.getMessages(userId);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const totalDocuments = documents.length;
    const totalValue = documents.reduce((sum, doc) => sum + (parseFloat(doc.value || "0")), 0);
    const duingToday = documents.filter(doc => {
      if (!doc.dueDate) return false;
      const dueDate = new Date(doc.dueDate);
      dueDate.setHours(0, 0, 0, 0);
      return dueDate.getTime() === today.getTime();
    }).length;
    const processedEmails = messages.length;

    return {
      totalDocuments,
      totalValue,
      duingToday,
      processedEmails,
    };
  }

  async getMonthlyValues(userId: string): Promise<Array<{ month: string; value: number }>> {
    const documents = await this.getDocuments(userId);
    const monthlyData: { [key: string]: number } = {};
    
    documents.forEach(doc => {
      if (doc.issueDate && doc.value) {
        const date = new Date(doc.issueDate);
        const monthKey = date.toLocaleDateString('pt-BR', { year: 'numeric', month: 'short' });
        monthlyData[monthKey] = (monthlyData[monthKey] || 0) + parseFloat(doc.value);
      }
    });
    
    return Object.entries(monthlyData).map(([month, value]) => ({ month, value }));
  }

  async getStatusCounts(userId: string): Promise<Array<{ status: string; count: number }>> {
    const documents = await this.getDocuments(userId);
    const statusCounts: { [key: string]: number } = {};
    
    documents.forEach(doc => {
      statusCounts[doc.status] = (statusCounts[doc.status] || 0) + 1;
    });
    
    return Object.entries(statusCounts).map(([status, count]) => ({ status, count }));
  }
}

export const storage = new MemStorage();
