import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { createGraphClient, getUserProfile, getEmailsWithAttachments } from "./microsoftAuth";
import { insertMessageSchema, insertDocumentSchema, insertUploadSchema } from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedMimes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Skip auth setup for demo
  // await setupAuth(app);

  // Simplified auth for demo - always return demo user
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      // Always return demo user for production demo
      const demoUser = await storage.getUser("demo-user-123");
      if (demoUser) {
        res.json(demoUser);
      } else {
        // Create demo user if it doesn't exist
        const newDemoUser = await storage.upsertUser({
          id: "demo-user-123",
          email: "demo@exemplo.com",
          firstName: "Usuario",
          lastName: "Demonstração"
        });
        res.json(newDemoUser);
      }
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Simplified login/logout for demo
  app.get('/api/login', (req, res) => {
    res.redirect('/');
  });

  app.get('/api/logout', (req, res) => {
    res.redirect('/');
  });

  // Microsoft Graph API integration
  app.post('/api/microsoft/sync', async (req, res) => {
    try {
      const { accessToken } = req.body;
      
      if (!accessToken) {
        return res.status(400).json({ message: "Access token is required" });
      }

      const userId = (req.session as any)?.demoUser?.id || "demo-user-123";
      
      // Create Graph client and get user profile
      const graphClient = createGraphClient(accessToken);
      const userProfile = await getUserProfile(graphClient);
      
      // Update user with Microsoft profile data
      await storage.upsertUser({
        id: userId,
        email: userProfile.email,
        firstName: userProfile.firstName,
        lastName: userProfile.lastName
      });

      // Get emails with attachments
      const emailsWithAttachments = await getEmailsWithAttachments(graphClient);
      
      // Process and store emails
      let processedCount = 0;
      for (const emailData of emailsWithAttachments) {
        const message = emailData.message;
        
        // Store message
        const storedMessage = await storage.createMessage({
          userId,
          subject: message.subject,
          fromEmail: message.from?.emailAddress?.address || '',
          receivedAt: new Date(message.receivedDateTime),
          hasAttachments: true
        });

        // Process attachments
        for (const attachment of emailData.attachments) {
          await storage.createAttachment({
            messageId: storedMessage.id,
            filename: attachment.name,
            mimeType: attachment.contentType,
            size: attachment.size.toString()
          });
        }
        
        processedCount++;
      }

      res.json({
        success: true,
        message: `Successfully synced ${processedCount} emails with financial attachments`,
        processedEmails: processedCount
      });

    } catch (error) {
      console.error("Error syncing Microsoft emails:", error);
      res.status(500).json({ 
        message: "Failed to sync Microsoft emails",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Check Microsoft Graph connection
  app.post('/api/microsoft/test', async (req, res) => {
    try {
      const { accessToken } = req.body;
      
      if (!accessToken) {
        return res.status(400).json({ message: "Access token is required" });
      }

      const graphClient = createGraphClient(accessToken);
      const userProfile = await getUserProfile(graphClient);
      
      res.json({
        success: true,
        user: userProfile,
        message: "Microsoft Graph API connection successful"
      });
    } catch (error) {
      console.error("Error testing Microsoft Graph:", error);
      res.status(500).json({ 
        message: "Failed to connect to Microsoft Graph",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      const stats = await storage.getDashboardStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get('/api/dashboard/monthly-values', async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      const data = await storage.getMonthlyValues(userId);
      res.json(data);
    } catch (error) {
      console.error("Error fetching monthly values:", error);
      res.status(500).json({ message: "Failed to fetch monthly values" });
    }
  });

  app.get('/api/dashboard/status-counts', async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      const data = await storage.getStatusCounts(userId);
      res.json(data);
    } catch (error) {
      console.error("Error fetching status counts:", error);
      res.status(500).json({ message: "Failed to fetch status counts" });
    }
  });

  // Messages/Emails
  app.get('/api/messages', async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      const messages = await storage.getMessages(userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post('/api/messages/sync', async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      
      // Mock Microsoft Graph API call - simulate finding new emails
      // In real implementation, this would call Microsoft Graph /me/messages
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // For demo, we'll just return success
      // In real implementation, new messages would be created here
      
      res.json({ 
        success: true, 
        message: "Email synchronization completed",
        newMessages: 0 
      });
    } catch (error) {
      console.error("Error syncing emails:", error);
      res.status(500).json({ message: "Failed to sync emails" });
    }
  });

  // Documents
  app.get('/api/documents', async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      const { startDate, endDate } = req.query;
      
      let documents;
      if (startDate || endDate) {
        const start = startDate ? new Date(startDate as string) : undefined;
        const end = endDate ? new Date(endDate as string) : undefined;
        documents = await storage.getDocumentsByDateRange(userId, start, end);
      } else {
        documents = await storage.getDocuments(userId);
      }
      
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  // File Upload
  app.post('/api/upload', upload.array('files'), async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      const files = req.files as Express.Multer.File[];
      
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const uploadPromises = files.map(async (file) => {
        const uploadItem = await storage.createUpload({
          userId,
          filename: file.filename,
          originalName: file.originalname,
          mimeType: file.mimetype,
          size: file.size.toString(),
          status: 'pending',
          progress: '0',
        });

        // Simulate file processing
        setTimeout(async () => {
          await storage.updateUploadStatus(uploadItem.id, 'processing', 50);
          
          setTimeout(async () => {
            // Mock document extraction
            const mockDocument = {
              userId,
              attachmentId: null,
              messageId: null,
              name: file.originalname.replace(/\.[^/.]+$/, ""),
              value: (Math.random() * 5000 + 100).toFixed(2),
              issueDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
              dueDate: new Date(Date.now() + Math.random() * 60 * 24 * 60 * 60 * 1000),
              status: 'processed',
              confidence: '85.5',
            };
            
            await storage.createDocument(mockDocument);
            await storage.updateUploadStatus(uploadItem.id, 'completed', 100);
          }, 3000);
        }, 1000);

        return uploadItem;
      });

      const uploads = await Promise.all(uploadPromises);
      res.json({ 
        success: true, 
        uploads: uploads.map(u => ({ id: u.id, filename: u.originalName }))
      });
    } catch (error) {
      console.error("Error uploading files:", error);
      res.status(500).json({ message: "Failed to upload files" });
    }
  });

  app.get('/api/upload/queue', async (req: any, res) => {
    try {
      const userId = (req.session as any)?.demoUser?.id || req.user?.claims?.sub || "demo-user-123";
      const queue = await storage.getUploadQueue(userId);
      res.json(queue);
    } catch (error) {
      console.error("Error fetching upload queue:", error);
      res.status(500).json({ message: "Failed to fetch upload queue" });
    }
  });

  // Download attachment (mock)
  app.get('/api/attachments/:id/download', async (req: any, res) => {
    try {
      const { id } = req.params;
      // Mock file download - in real implementation would serve actual file
      res.json({ 
        success: true, 
        message: "File download would start here",
        downloadUrl: `/uploads/${id}` 
      });
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
