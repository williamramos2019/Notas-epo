import { Client } from '@microsoft/microsoft-graph-client';
import { AuthenticationProvider } from '@microsoft/microsoft-graph-client';
import { AuthenticationResult } from '@azure/msal-node';

// Microsoft Graph configuration
export const msalConfig = {
  auth: {
    clientId: process.env.MICROSOFT_CLIENT_ID || '',
    clientSecret: process.env.MICROSOFT_CLIENT_SECRET || '',
    authority: 'https://login.microsoftonline.com/common'
  }
};

export const graphScopes = [
  'https://graph.microsoft.com/User.Read',
  'https://graph.microsoft.com/Mail.Read',
  'https://graph.microsoft.com/Mail.ReadBasic',
  'https://graph.microsoft.com/Files.Read'
];

// Custom authentication provider for Microsoft Graph
class TokenAuthProvider implements AuthenticationProvider {
  private accessToken: string;

  constructor(accessToken: string) {
    this.accessToken = accessToken;
  }

  async getAccessToken(): Promise<string> {
    return this.accessToken;
  }
}

// Create Graph client with access token
export function createGraphClient(accessToken: string): Client {
  const authProvider = new TokenAuthProvider(accessToken);
  return Client.initWithMiddleware({ authProvider });
}

// Get user profile from Microsoft Graph
export async function getUserProfile(graphClient: Client) {
  try {
    const user = await graphClient.api('/me').get();
    return {
      id: user.id,
      email: user.mail || user.userPrincipalName,
      firstName: user.givenName,
      lastName: user.surname,
      displayName: user.displayName
    };
  } catch (error) {
    console.error('Error getting user profile:', error);
    throw error;
  }
}

// Get emails from Outlook with attachments
export async function getEmailsWithAttachments(graphClient: Client, maxEmails = 50) {
  try {
    // Get recent emails with attachments
    const messages = await graphClient
      .api('/me/messages')
      .filter('hasAttachments eq true')
      .select('id,subject,from,receivedDateTime,hasAttachments,body')
      .orderby('receivedDateTime desc')
      .top(maxEmails)
      .get();

    const emailsWithAttachments = [];

    for (const message of messages.value) {
      // Get attachments for each message
      const attachments = await graphClient
        .api(`/me/messages/${message.id}/attachments`)
        .get();

      // Filter for financial document attachments (PDF, images)
      const financialAttachments = attachments.value.filter((attachment: any) => {
        const name = attachment.name?.toLowerCase() || '';
        const isFinancialDoc = 
          name.includes('fatura') || 
          name.includes('boleto') || 
          name.includes('recibo') || 
          name.includes('invoice') || 
          name.includes('bill') ||
          name.includes('conta') ||
          name.includes('cobrança');
        
        const isPdfOrImage = 
          name.endsWith('.pdf') || 
          name.endsWith('.jpg') || 
          name.endsWith('.jpeg') || 
          name.endsWith('.png');
          
        return isFinancialDoc && isPdfOrImage;
      });

      if (financialAttachments.length > 0) {
        emailsWithAttachments.push({
          message,
          attachments: financialAttachments
        });
      }
    }

    return emailsWithAttachments;
  } catch (error) {
    console.error('Error getting emails with attachments:', error);
    throw error;
  }
}

// Download attachment content
export async function downloadAttachment(graphClient: Client, messageId: string, attachmentId: string) {
  try {
    const attachment = await graphClient
      .api(`/me/messages/${messageId}/attachments/${attachmentId}`)
      .get();

    return {
      id: attachment.id,
      name: attachment.name,
      contentType: attachment.contentType,
      size: attachment.size,
      content: attachment.contentBytes // Base64 encoded content
    };
  } catch (error) {
    console.error('Error downloading attachment:', error);
    throw error;
  }
}