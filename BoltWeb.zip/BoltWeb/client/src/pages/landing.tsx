import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, Computer, Eye } from "lucide-react";
import { useEffect } from "react";

export default function Landing() {
  // Auto redirect since auth is simplified for demo
  useEffect(() => {
    window.location.href = "/";
  }, []);

  const handleLogin = () => {
    window.location.href = "/";
  };

  const handleDemo = () => {
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-primary rounded-xl flex items-center justify-center mb-6">
            <DollarSign className="text-2xl text-primary-foreground" />
          </div>
          <h2 className="text-3xl font-bold text-foreground">Sistema de Gestão</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Faça login com sua conta Computer para continuar
          </p>
        </div>
        
        <Card className="shadow-lg">
          <CardContent className="p-8 space-y-6">
            <div className="space-y-4">
              <Button 
                onClick={handleLogin}
                className="w-full flex items-center justify-center"
                data-testid="button-microsoft-login"
              >
                <Computer className="mr-3 h-4 w-4" />
                Entrar com Computer
              </Button>
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Ou</span>
                </div>
              </div>
              
              <Button 
                variant="outline"
                onClick={handleDemo}
                className="w-full flex items-center justify-center"
                data-testid="button-demo"
              >
                <Eye className="mr-2 h-4 w-4" />
                Ver Demonstração
              </Button>
            </div>
            
            <div className="text-xs text-muted-foreground text-center space-y-2">
              <p>Ao continuar, você concorda com nossos</p>
              <div className="flex justify-center space-x-4">
                <a href="#" className="hover:text-primary">Termos de Uso</a>
                <span>•</span>
                <a href="#" className="hover:text-primary">Política de Privacidade</a>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
