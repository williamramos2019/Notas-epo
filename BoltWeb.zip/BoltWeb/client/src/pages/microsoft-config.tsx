import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle, XCircle, Mail, Key, RefreshCw, AlertTriangle } from "lucide-react";
import Header from "@/components/header";
import Navigation from "@/components/navigation";

export default function MicrosoftConfig() {
  const { toast } = useToast();
  const [accessToken, setAccessToken] = useState("");
  const [connectionStatus, setConnectionStatus] = useState<"idle" | "connected" | "error">("idle");
  const [userInfo, setUserInfo] = useState<any>(null);

  const testConnection = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/microsoft/test", { accessToken });
    },
    onSuccess: (data: any) => {
      setConnectionStatus("connected");
      setUserInfo(data.user);
      toast({
        title: "Conexão bem-sucedida!",
        description: "Microsoft Graph API conectado com sucesso.",
      });
    },
    onError: (error) => {
      setConnectionStatus("error");
      setUserInfo(null);
      toast({
        title: "Erro na conexão",
        description: "Falha ao conectar com Microsoft Graph API. Verifique o token.",
        variant: "destructive",
      });
    },
  });

  const syncEmails = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/microsoft/sync", { accessToken });
    },
    onSuccess: (data: any) => {
      toast({
        title: "Sincronização concluída!",
        description: `${data.processedEmails} e-mails processados com sucesso.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Erro na sincronização",
        description: "Falha ao sincronizar e-mails. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const getStatusIcon = () => {
    switch (connectionStatus) {
      case "connected":
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case "error":
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
    }
  };

  const getStatusBadge = () => {
    switch (connectionStatus) {
      case "connected":
        return <Badge className="bg-green-100 text-green-800">Conectado</Badge>;
      case "error":
        return <Badge variant="destructive">Erro de Conexão</Badge>;
      default:
        return <Badge variant="secondary">Não Conectado</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation activeTab="config" />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-foreground">Configuração Microsoft</h1>
            <p className="text-muted-foreground mt-2">
              Configure a integração com Microsoft Outlook para sincronização automática de e-mails
            </p>
          </div>

          {/* Connection Status */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {getStatusIcon()}
                  <CardTitle>Status da Conexão</CardTitle>
                </div>
                {getStatusBadge()}
              </div>
            </CardHeader>
            <CardContent>
              {userInfo ? (
                <div className="space-y-2">
                  <p><strong>Nome:</strong> {userInfo.displayName}</p>
                  <p><strong>Email:</strong> {userInfo.email}</p>
                  <p><strong>ID:</strong> {userInfo.id}</p>
                </div>
              ) : (
                <p className="text-muted-foreground">
                  Configure o token de acesso abaixo para conectar com Microsoft Graph API
                </p>
              )}
            </CardContent>
          </Card>

          {/* Access Token Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Key className="mr-2 h-5 w-5" />
                Token de Acesso Microsoft
              </CardTitle>
              <CardDescription>
                Insira seu token de acesso do Microsoft Graph API para conectar com sua conta Outlook
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="access-token">Access Token</Label>
                <Textarea
                  id="access-token"
                  placeholder="Insira o token de acesso do Microsoft Graph API..."
                  value={accessToken}
                  onChange={(e) => setAccessToken(e.target.value)}
                  className="min-h-[100px] font-mono text-sm"
                  data-testid="input-access-token"
                />
              </div>
              
              <div className="flex space-x-3">
                <Button 
                  onClick={() => testConnection.mutate()}
                  disabled={!accessToken || testConnection.isPending}
                  data-testid="button-test-connection"
                >
                  <RefreshCw className={`mr-2 h-4 w-4 ${testConnection.isPending ? 'animate-spin' : ''}`} />
                  Testar Conexão
                </Button>
                
                <Button 
                  onClick={() => syncEmails.mutate()}
                  disabled={!accessToken || connectionStatus !== "connected" || syncEmails.isPending}
                  variant="outline"
                  data-testid="button-sync-emails"
                >
                  <Mail className={`mr-2 h-4 w-4 ${syncEmails.isPending ? 'animate-spin' : ''}`} />
                  Sincronizar E-mails
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Instructions */}
          <Card>
            <CardHeader>
              <CardTitle>Como obter o Token de Acesso</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-medium">1. Acesse o Microsoft Graph Explorer</h4>
                <p className="text-sm text-muted-foreground">
                  Vá para <a href="https://developer.microsoft.com/en-us/graph/graph-explorer" 
                  target="_blank" className="text-primary hover:underline">
                    https://developer.microsoft.com/en-us/graph/graph-explorer
                  </a>
                </p>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium">2. Faça login com sua conta Microsoft</h4>
                <p className="text-sm text-muted-foreground">
                  Use a mesma conta do Outlook que deseja sincronizar
                </p>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium">3. Autorize as permissões necessárias</h4>
                <p className="text-sm text-muted-foreground">
                  Clique em "Modify permissions" e autorize: Mail.Read, User.Read
                </p>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium">4. Copie o Access Token</h4>
                <p className="text-sm text-muted-foreground">
                  Na aba "Access token", copie todo o token e cole no campo acima
                </p>
              </div>
            </CardContent>
          </Card>

        </div>
      </main>
    </div>
  );
}