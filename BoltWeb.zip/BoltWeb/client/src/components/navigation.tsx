import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Gauge, Mail, FileText, Upload, Settings } from "lucide-react";

interface NavigationProps {
  activeTab: string;
}

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: Gauge, path: "/" },
  { id: "emails", label: "E-mails", icon: Mail, path: "/emails" },
  { id: "documents", label: "Documentos", icon: FileText, path: "/documents" },
  { id: "upload", label: "Upload", icon: Upload, path: "/upload" },
  { id: "config", label: "Microsoft", icon: Settings, path: "/config" },
];

export default function Navigation({ activeTab }: NavigationProps) {
  const [, setLocation] = useLocation();

  return (
    <div className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-8" aria-label="Tabs">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => setLocation(item.path)}
                className={cn(
                  "py-4 px-1 border-b-2 font-medium text-sm transition-colors",
                  isActive 
                    ? "border-primary text-primary" 
                    : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
                )}
                data-testid={`tab-${item.id}`}
              >
                <Icon className="mr-2 h-4 w-4" />
                {item.label}
              </Button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
