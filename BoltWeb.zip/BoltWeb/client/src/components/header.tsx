import { useAuth } from "@/hooks/useAuth";
import { Bell, ChevronDown, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Header() {
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.[0] || ""}${lastName?.[0] || ""}`.toUpperCase();
  };

  return (
    <header className="bg-card border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center">
                <DollarSign className="text-sm text-primary-foreground" />
              </div>
            </div>
            <div className="ml-4">
              <h1 className="text-lg font-semibold text-foreground">Sistema de Gestão</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <Bell className="text-muted-foreground" />
            </Button>
            <Button 
              variant="ghost" 
              onClick={handleLogout}
              className="flex items-center space-x-2 p-2 rounded-lg hover:bg-secondary transition-colors"
              data-testid="button-user-menu"
            >
              <div className="h-6 w-6 bg-primary rounded-full flex items-center justify-center">
                <span className="text-xs text-primary-foreground font-medium">
                  {getInitials((user as any)?.firstName, (user as any)?.lastName)}
                </span>
              </div>
              <span className="text-sm text-foreground" data-testid="text-username">
                {(user as any)?.firstName || (user as any)?.email || "Usuário"}
              </span>
              <ChevronDown className="text-xs text-muted-foreground" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
