import { useState, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { CloudUpload, FileUp, Folder, File, CheckCircle, AlertCircle } from "lucide-react";
import type { UploadItem } from "@shared/schema";

export default function UploadArea() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [settings, setSettings] = useState({
    autoExtraction: true,
    emailNotifications: true,
    autoBackup: false,
  });

  const { data: uploadQueue } = useQuery<UploadItem[]>({
    queryKey: ["/api/upload/queue"],
    refetchInterval: 2000, // Poll every 2 seconds for updates
  });

  const uploadMutation = useMutation({
    mutationFn: async (files: FileList) => {
      const formData = new FormData();
      Array.from(files).forEach(file => {
        formData.append('files', file);
      });
      return await apiRequest("POST", "/api/upload", formData);
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "Arquivos enviados com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/upload/queue"] });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Erro ao enviar arquivos. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (files: FileList | null) => {
    if (files && files.length > 0) {
      uploadMutation.mutate(files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const files = e.dataTransfer.files;
    handleFileSelect(files);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'failed':
        return <AlertCircle className="h-5 w-5 text-red-600" />;
      default:
        return <File className="h-5 w-5 text-blue-600" />;
    }
  };

  const getStatusText = (status: string) => {
    const statusMap = {
      'pending': 'Aguardando...',
      'processing': 'Processando...',
      'completed': 'Concluído',
      'failed': 'Erro'
    };
    return statusMap[status as keyof typeof statusMap] || status;
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <Card className="shadow-sm">
        <CardContent className="p-8">
          <div className="text-center">
            <div className="mx-auto h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <CloudUpload className="text-2xl text-primary" />
            </div>
            <CardTitle className="text-lg font-semibold mb-2">Upload de Documentos</CardTitle>
            <p className="text-sm text-muted-foreground mb-6">
              Arraste e solte seus arquivos aqui ou clique para selecionar
            </p>
            
            {/* Drop Zone */}
            <div 
              className={`border-2 border-dashed rounded-lg p-12 transition-colors cursor-pointer ${
                dragOver ? 'border-primary/50 bg-primary/5' : 'border-border hover:border-primary/50 hover:bg-primary/5'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              data-testid="upload-dropzone"
            >
              <div className="flex flex-col items-center space-y-4">
                <FileUp className="h-12 w-12 text-muted-foreground" />
                <div>
                  <p className="text-lg font-medium text-foreground">Selecione arquivos</p>
                  <p className="text-sm text-muted-foreground">ou arraste e solte aqui</p>
                </div>
                <p className="text-xs text-muted-foreground">
                  Formatos suportados: PDF, JPG, PNG (máx. 10MB)
                </p>
              </div>
            </div>
            
            <input 
              type="file" 
              ref={fileInputRef}
              multiple 
              accept=".pdf,.jpg,.jpeg,.png"
              className="hidden"
              onChange={(e) => handleFileSelect(e.target.files)}
              data-testid="file-input"
            />
            
            <div className="mt-6 flex justify-center space-x-4">
              <Button 
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadMutation.isPending}
                data-testid="button-select-files"
              >
                <FileUp className="mr-2 h-4 w-4" />
                Selecionar Arquivos
              </Button>
              <Button variant="outline" data-testid="button-choose-folder">
                <Folder className="mr-2 h-4 w-4" />
                Escolher Pasta
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upload Queue */}
      {uploadQueue && uploadQueue.length > 0 && (
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>Fila de Upload</CardTitle>
            <p className="text-sm text-muted-foreground">Processando seus arquivos...</p>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border" data-testid="upload-queue">
              {uploadQueue.map((item) => (
                <div key={item.id} className="p-6 flex items-center space-x-4" data-testid={`upload-item-${item.id}`}>
                  <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    {getStatusIcon(item.status)}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground" data-testid={`upload-filename-${item.id}`}>
                      {item.originalName}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {Math.round(parseInt(item.size || "0") / 1024)} KB
                    </p>
                    <div className="mt-2">
                      <Progress 
                        value={parseFloat(item.progress || "0")} 
                        className="h-2"
                        data-testid={`upload-progress-${item.id}`}
                      />
                    </div>
                  </div>
                  <div className="text-sm" data-testid={`upload-status-${item.id}`}>
                    {getStatusText(item.status)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Processing Options */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Opções de Processamento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium">Extração automática de dados</Label>
              <p className="text-sm text-muted-foreground">
                Extrair valores, datas e informações relevantes
              </p>
            </div>
            <Switch 
              checked={settings.autoExtraction}
              onCheckedChange={(checked) => setSettings({...settings, autoExtraction: checked})}
              data-testid="switch-auto-extraction"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium">Notificações por e-mail</Label>
              <p className="text-sm text-muted-foreground">Receber alertas sobre vencimentos</p>
            </div>
            <Switch 
              checked={settings.emailNotifications}
              onCheckedChange={(checked) => setSettings({...settings, emailNotifications: checked})}
              data-testid="switch-email-notifications"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium">Backup automático</Label>
              <p className="text-sm text-muted-foreground">
                Manter cópias de segurança dos arquivos
              </p>
            </div>
            <Switch 
              checked={settings.autoBackup}
              onCheckedChange={(checked) => setSettings({...settings, autoBackup: checked})}
              data-testid="switch-auto-backup"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
