import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Mail, FolderSync, Building, CreditCard, Paperclip, Eye } from "lucide-react";
import type { Message } from "@shared/schema";

export default function EmailList() {
  const { toast } = useToast();

  const { data: messages, isLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/messages/sync");
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "E-mails sincronizados com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Erro ao sincronizar e-mails. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getEmailIcon = (fromEmail: string) => {
    if (fromEmail.includes('banco') || fromEmail.includes('bank')) {
      return <Building className="text-blue-600" />;
    }
    if (fromEmail.includes('cartao') || fromEmail.includes('card')) {
      return <CreditCard className="text-orange-600" />;
    }
    return <Mail className="text-purple-600" />;
  };

  return (
    <div className="space-y-6">
      {/* FolderSync Status */}
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Mail className="text-green-600" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Sincronização de E-mails</h3>
                <p className="text-sm text-muted-foreground">
                  Última sincronização: {messages?.length ? 'há alguns minutos' : 'nunca'}
                </p>
              </div>
            </div>
            <Button 
              onClick={() => syncMutation.mutate()}
              disabled={syncMutation.isPending}
              data-testid="button-sync-emails"
            >
              <FolderSync className={`mr-2 h-4 w-4 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
              Sincronizar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Email List */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>E-mails Processados</CardTitle>
          <p className="text-sm text-muted-foreground">Visualize e gerencie e-mails com anexos</p>
        </CardHeader>
        
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Carregando e-mails...</p>
            </div>
          ) : !messages || messages.length === 0 ? (
            <div className="p-8 text-center">
              <Mail className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">Nenhum e-mail encontrado</h3>
              <p className="text-muted-foreground mb-4">
                Clique em "Sincronizar" para buscar e-mails da sua conta Microsoft
              </p>
              <Button 
                onClick={() => syncMutation.mutate()}
                disabled={syncMutation.isPending}
                data-testid="button-sync-empty-state"
              >
                <FolderSync className={`mr-2 h-4 w-4 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
                Sincronizar E-mails
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {messages.map((message) => (
                <div 
                  key={message.id} 
                  className="p-6 hover:bg-muted/50 transition-colors"
                  data-testid={`email-item-${message.id}`}
                >
                  <div className="flex items-start space-x-4">
                    <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                      {getEmailIcon(message.fromEmail)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-foreground truncate" data-testid={`email-subject-${message.id}`}>
                          {message.subject}
                        </p>
                        <div className="ml-2 flex-shrink-0 flex items-center space-x-2">
                          {message.hasAttachments && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                              anexos
                            </span>
                          )}
                          <span className="text-sm text-muted-foreground">
                            {formatTime(message.receivedAt)}
                          </span>
                        </div>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground" data-testid={`email-from-${message.id}`}>
                        De: {message.fromEmail}
                      </p>
                      <p className="mt-1 text-sm text-foreground">
                        E-mail processado automaticamente pelo sistema...
                      </p>
                      <div className="mt-3 flex items-center space-x-4">
                        <Button variant="link" className="p-0 h-auto text-primary" data-testid={`button-attachments-${message.id}`}>
                          <Paperclip className="mr-1 h-3 w-3" />
                          Ver anexos
                        </Button>
                        <Button variant="link" className="p-0 h-auto text-muted-foreground hover:text-foreground" data-testid={`button-view-${message.id}`}>
                          <Eye className="mr-1 h-3 w-3" />
                          Visualizar
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
