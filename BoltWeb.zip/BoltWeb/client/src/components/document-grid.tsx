import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Grid3x3, List, FileText, Image, MoreHorizontal, Download, Eye } from "lucide-react";
import type { Document } from "@shared/schema";

export default function DocumentGrid() {
  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });

  const handleDownload = async (document: Document) => {
    try {
      // Download document via attachment API
      const link = `/api/attachments/${document.attachmentId}/download`;
      window.open(link, '_blank');
    } catch (error) {
      console.error('Error downloading document:', error);
    }
  };

  const handleView = async (document: Document) => {
    try {
      // Open document in new tab for viewing
      const link = `/api/attachments/${document.attachmentId}/download`;
      window.open(link, '_blank');
    } catch (error) {
      console.error('Error viewing document:', error);
    }
  };

  const getFileIcon = (name: string) => {
    const extension = name.split('.').pop()?.toLowerCase();
    if (['pdf'].includes(extension || '')) {
      return <FileText className="text-blue-600" />;
    }
    if (['jpg', 'jpeg', 'png'].includes(extension || '')) {
      return <Image className="text-orange-600" />;
    }
    return <FileText className="text-purple-600" />;
  };

  const formatCurrency = (value: string | null) => {
    if (!value) return "R$ 0,00";
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(parseFloat(value));
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "Data não informada";
    const dueDate = new Date(date);
    const today = new Date();
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Vence hoje";
    if (diffDays < 0) return "Vencido";
    if (diffDays === 1) return "Vence amanhã";
    return `Vence em ${dueDate.toLocaleDateString('pt-BR')}`;
  };

  const getDateColor = (date: Date | null) => {
    if (!date) return "text-muted-foreground";
    const dueDate = new Date(date);
    const today = new Date();
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "text-orange-600";
    if (diffDays < 0) return "text-red-600";
    return "text-muted-foreground";
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Biblioteca de Documentos</CardTitle>
              <p className="text-sm text-muted-foreground">Gerencie todos os seus arquivos processados</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="icon" className="border-primary text-primary">
                <Grid3x3 className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <Card key={i} className="border">
                  <CardContent className="p-4">
                    <div className="animate-pulse space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="h-12 w-12 bg-muted rounded-lg"></div>
                        <div className="h-4 w-4 bg-muted rounded"></div>
                      </div>
                      <div className="h-4 bg-muted rounded"></div>
                      <div className="h-3 bg-muted rounded w-2/3"></div>
                      <div className="h-4 bg-muted rounded w-1/2"></div>
                      <div className="h-3 bg-muted rounded w-3/4"></div>
                      <div className="flex space-x-2">
                        <div className="flex-1 h-8 bg-muted rounded"></div>
                        <div className="h-8 w-12 bg-muted rounded"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !documents || documents.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">Nenhum documento encontrado</h3>
              <p className="text-muted-foreground">
                Faça upload de arquivos ou sincronize seus e-mails para começar
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {documents.map((document) => (
                <Card key={document.id} className="border hover:shadow-md transition-shadow" data-testid={`document-card-${document.id}`}>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        {getFileIcon(document.name)}
                      </div>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-foreground truncate" data-testid={`document-name-${document.id}`}>
                        {document.name}
                      </h4>
                      <p className="text-sm text-muted-foreground">PDF</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-foreground font-medium" data-testid={`document-value-${document.id}`}>
                        {formatCurrency(document.value)}
                      </p>
                      <p className={`text-xs ${getDateColor(document.dueDate)}`} data-testid={`document-due-${document.id}`}>
                        {formatDate(document.dueDate)}
                      </p>
                    </div>
                    
                    <div className="flex space-x-2 pt-2">
                      <Button 
                        size="sm" 
                        className="flex-1" 
                        onClick={() => handleDownload(document)}
                        data-testid={`button-download-${document.id}`}
                      >
                        <Download className="mr-1 h-3 w-3" />
                        Baixar
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleView(document)}
                        data-testid={`button-view-${document.id}`}
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
