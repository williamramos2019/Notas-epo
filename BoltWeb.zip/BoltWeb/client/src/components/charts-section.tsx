import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MoreHorizontal } from "lucide-react";

declare global {
  interface Window {
    Chart: any;
  }
}

export default function ChartsSection() {
  const monthlyChartRef = useRef<HTMLCanvasElement>(null);
  const statusChartRef = useRef<HTMLCanvasElement>(null);

  const { data: monthlyData, isLoading: monthlyLoading } = useQuery({
    queryKey: ["/api/dashboard/monthly-values"],
  });

  const { data: statusData, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/dashboard/status-counts"],
  });

  useEffect(() => {
    // Load Chart.js from CDN
    if (!window.Chart) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
      script.onload = () => {
        initializeCharts();
      };
      document.head.appendChild(script);
    } else {
      initializeCharts();
    }
  }, [monthlyData, statusData]);

  const initializeCharts = () => {
    if (!window.Chart || monthlyLoading || statusLoading) return;

    // Monthly values chart
    if (monthlyChartRef.current && monthlyData && Array.isArray(monthlyData)) {
      const ctx = monthlyChartRef.current.getContext('2d');
      new window.Chart(ctx, {
        type: 'line',
        data: {
          labels: monthlyData.map((item: any) => item.month),
          datasets: [{
            label: 'Valores (R$)',
            data: monthlyData.map((item: any) => item.value),
            borderColor: '#0078D4',
            backgroundColor: 'rgba(0, 120, 212, 0.1)',
            tension: 0.4,
            fill: true,
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                callback: function(value: any) {
                  return 'R$ ' + value.toLocaleString('pt-BR');
                }
              }
            }
          },
          plugins: {
            legend: {
              display: false
            }
          }
        }
      });
    }

    // Status pie chart
    if (statusChartRef.current && statusData && Array.isArray(statusData)) {
      const ctx = statusChartRef.current.getContext('2d');
      const colors = {
        'processed': '#28A745',
        'pending': '#FFC107', 
        'expired': '#DC3545',
        'due_today': '#FD7E14'
      };

      new window.Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: statusData.map((item: any) => {
            const statusLabels = {
              'processed': 'Processados',
              'pending': 'Pendentes',
              'expired': 'Vencidos',
              'due_today': 'Vencendo'
            };
            return statusLabels[item.status as keyof typeof statusLabels] || item.status;
          }),
          datasets: [{
            data: statusData.map((item: any) => item.count),
            backgroundColor: statusData.map((item: any) => colors[item.status as keyof typeof colors] || '#6B7280'),
            borderWidth: 0,
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '60%',
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                usePointStyle: true,
                padding: 20
              }
            }
          }
        }
      });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Valores por Mês</CardTitle>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="text-xs">6M</Button>
              <Button size="sm" className="text-xs">12M</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48">
            <canvas ref={monthlyChartRef} data-testid="chart-monthly-values"></canvas>
          </div>
        </CardContent>
      </Card>
      
      <Card className="shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Status dos Títulos</CardTitle>
            <Button variant="ghost" size="icon">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48">
            <canvas ref={statusChartRef} data-testid="chart-status"></canvas>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
