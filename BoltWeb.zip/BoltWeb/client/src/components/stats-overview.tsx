import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, DollarSign, AlertTriangle, Mail } from "lucide-react";

export default function StatsOverview() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="shadow-sm">
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-8 bg-muted rounded mb-4"></div>
                <div className="h-4 bg-muted rounded w-2/3"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statCards = [
    {
      title: "Total de Títulos",
      value: (stats as any)?.totalDocuments || 0,
      icon: FileText,
      color: "blue",
      change: "+12.5%",
      changeColor: "green",
    },
    {
      title: "Valor Total", 
      value: `R$ ${(stats as any)?.totalValue?.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || "0,00"}`,
      icon: DollarSign,
      color: "green",
      change: "+8.2%",
      changeColor: "green",
    },
    {
      title: "Vencendo Hoje",
      value: (stats as any)?.duingToday || 0,
      icon: AlertTriangle,
      color: "orange",
      change: "Atenção",
      changeColor: "orange",
    },
    {
      title: "E-mails Processados",
      value: (stats as any)?.processedEmails || 0,
      icon: Mail,
      color: "purple",
      change: "+24.1%",
      changeColor: "green",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        
        return (
          <Card key={index} className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground" data-testid={`stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}-title`}>
                    {stat.title}
                  </p>
                  <p className="text-2xl font-bold text-foreground" data-testid={`stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}-value`}>
                    {stat.value}
                  </p>
                </div>
                <div className={`h-12 w-12 bg-${stat.color}-100 rounded-lg flex items-center justify-center`}>
                  <Icon className={`text-${stat.color}-600`} />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <span className={`text-${stat.changeColor}-600 font-medium`}>
                  {stat.change}
                </span>
                <span className="text-muted-foreground ml-1">vs mês anterior</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
