import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { FolderSync, Download, Search, FileText, MoreVertical } from "lucide-react";
import type { Document } from "@shared/schema";

export default function DocumentsTable() {
  const { toast } = useToast();
  const [filters, setFilters] = useState({
    period: "",
    startDate: "",
    endDate: "",
    search: "",
  });

  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ["/api/documents", filters.startDate, filters.endDate],
  });

  const handleDownload = async (document: Document) => {
    try {
      const link = `/api/attachments/${document.attachmentId}/download`;
      window.open(link, '_blank');
    } catch (error) {
      console.error('Error downloading document:', error);
    }
  };

  const handleExport = () => {
    try {
      // Export all documents to CSV
      if (!documents || documents.length === 0) {
        toast({
          title: "Aviso",
          description: "Nenhum documento para exportar",
          variant: "destructive",
        });
        return;
      }

      const csvContent = [
        ['Nome', 'Valor', 'Data Emissão', 'Data Vencimento', 'Status'].join(','),
        ...documents.map(doc => [
          `"${doc.name}"`,
          `"${doc.value || '0'}"`,
          `"${doc.issueDate ? new Date(doc.issueDate).toLocaleDateString('pt-BR') : ''}"`,
          `"${doc.dueDate ? new Date(doc.dueDate).toLocaleDateString('pt-BR') : ''}"`,
          `"${doc.status}"`
        ].join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'documentos_financeiros.csv';
      link.click();
      
      toast({
        title: "Sucesso",
        description: "Documentos exportados com sucesso!",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao exportar documentos",
        variant: "destructive",
      });
    }
  };

  const syncMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/messages/sync");
    },
    onSuccess: () => {
      toast({
        title: "Sucesso",
        description: "E-mails sincronizados com sucesso!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Erro ao sincronizar e-mails. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      processed: { label: "Processado", variant: "default" as const, className: "bg-green-100 text-green-800" },
      pending: { label: "Pendente", variant: "secondary" as const, className: "bg-orange-100 text-orange-800" },
      expired: { label: "Vencido", variant: "destructive" as const, className: "bg-red-100 text-red-800" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return (
      <Badge variant={config.variant} className={config.className}>
        {config.label}
      </Badge>
    );
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const formatCurrency = (value: string | null) => {
    if (!value) return "-";
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(parseFloat(value));
  };

  const filteredDocuments = documents?.filter(doc => {
    if (filters.search && !doc.name.toLowerCase().includes(filters.search.toLowerCase())) {
      return false;
    }
    return true;
  }) || [];

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <CardTitle className="text-lg font-semibold">Títulos Recentes</CardTitle>
            <p className="text-sm text-muted-foreground">Gerencie seus documentos financeiros</p>
          </div>
          <div className="flex space-x-3">
            <Button 
              variant="outline"
              onClick={() => syncMutation.mutate()}
              disabled={syncMutation.isPending}
              data-testid="button-sync"
            >
              <FolderSync className={`mr-2 h-4 w-4 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
              Sincronizar
            </Button>
            <Button onClick={handleExport} data-testid="button-export">
              <Download className="mr-2 h-4 w-4" />
              Exportar
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <div>
            <Label htmlFor="period">Período</Label>
            <Select value={filters.period} onValueChange={(value) => setFilters({...filters, period: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Selecionar período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="last-month">Último mês</SelectItem>
                <SelectItem value="last-3-months">Últimos 3 meses</SelectItem>
                <SelectItem value="last-6-months">Últimos 6 meses</SelectItem>
                <SelectItem value="this-year">Este ano</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="start-date">Data Inicial</Label>
            <Input 
              id="start-date"
              type="date"
              value={filters.startDate}
              onChange={(e) => setFilters({...filters, startDate: e.target.value})}
              data-testid="input-start-date"
            />
          </div>
          
          <div>
            <Label htmlFor="end-date">Data Final</Label>
            <Input 
              id="end-date"
              type="date"
              value={filters.endDate}
              onChange={(e) => setFilters({...filters, endDate: e.target.value})}
              data-testid="input-end-date"
            />
          </div>
          
          <div>
            <Label htmlFor="search">Buscar</Label>
            <div className="relative">
              <Input 
                id="search"
                placeholder="Nome do título..."
                value={filters.search}
                onChange={(e) => setFilters({...filters, search: e.target.value})}
                className="pl-10"
                data-testid="input-search"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          {isLoading ? (
            <div className="p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-muted-foreground">Carregando documentos...</p>
            </div>
          ) : filteredDocuments.length === 0 ? (
            <div className="p-8 text-center">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhum documento encontrado</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Emissão</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.map((doc) => (
                  <TableRow key={doc.id} className="hover:bg-muted/50" data-testid={`row-document-${doc.id}`}>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="h-8 w-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                          <FileText className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-foreground" data-testid={`text-document-name-${doc.id}`}>
                            {doc.name}
                          </div>
                          <div className="text-sm text-muted-foreground">PDF</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium" data-testid={`text-document-value-${doc.id}`}>
                      {formatCurrency(doc.value)}
                    </TableCell>
                    <TableCell className="text-muted-foreground" data-testid={`text-document-issue-${doc.id}`}>
                      {formatDate(doc.issueDate)}
                    </TableCell>
                    <TableCell className="text-muted-foreground" data-testid={`text-document-due-${doc.id}`}>
                      {formatDate(doc.dueDate)}
                    </TableCell>
                    <TableCell data-testid={`status-${doc.id}`}>
                      {getStatusBadge(doc.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleDownload(doc)}
                          data-testid={`button-download-${doc.id}`}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
