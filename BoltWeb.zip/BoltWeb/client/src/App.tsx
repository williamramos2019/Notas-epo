import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
// Removed auth dependencies for simplified demo
import Dashboard from "@/pages/dashboard";
import Emails from "@/pages/emails";
import Documents from "@/pages/documents";
import Upload from "@/pages/upload";
import MicrosoftConfig from "@/pages/microsoft-config";
import NotFound from "@/pages/not-found";

function Router() {
  // Simplified routing - always show main app for demo
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/emails" component={Emails} />
      <Route path="/documents" component={Documents} />
      <Route path="/upload" component={Upload} />
      <Route path="/config" component={MicrosoftConfig} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
